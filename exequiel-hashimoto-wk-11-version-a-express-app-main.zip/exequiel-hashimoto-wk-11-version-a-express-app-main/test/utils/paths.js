module.exports = {
  formPath: '/entrees/new',
  formHandlerPath: '/entrees',
  mainPath: '/',
}